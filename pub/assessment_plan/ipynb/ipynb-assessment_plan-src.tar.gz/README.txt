This IPython notebook assessment_plan.ipynb does not require any additional
programs.
