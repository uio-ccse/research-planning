This IPython notebook CCSE_research_meeting.ipynb does not require any additional
programs.
